1.  Right click the *References* folder within your project -> **Edit References** -> **.Net Assembly** -> Navigate to download location of kinvey library, and add all the dll files.
2. Right click your project ->  **Add** ->  **Add Packages** 


Microsoft.Bcl version="1.1.0" 
Microsoft.Bcl.Async version="1.0.168"
Microsoft.Bcl.Build version="1.0.21"
Microsoft.Net.Http version="2.2.29"
modernhttpclient version="2.4.2"
Newtonsoft.Json version="6.0.8"
SQLite.Net.Async-PCL version="3.0.5"
SQLite.Net-PCL version="3.0.5"
Kinvey version="1.5.0"