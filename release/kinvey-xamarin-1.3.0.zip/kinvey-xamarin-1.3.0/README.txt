1.  Right click the *References* folder within your project -> **Edit References** -> **.Net Assembly** -> Navigate to download location of kinvey library, and add all the dll files.
2. Right click your project ->  **Add** ->  **Add Packages** 
	1. 	Add "Json.NET" v6.0.6 
	2.  Add "SQLite.Net.Async PCL" v2.4.1
	3.  Add "SQLite.Net PCL - <runtime> Platform" v2.4.1 where <runtime> is your project's target platform
	4. Add "LinqExtender" v3.0.1
	5. Add "Microsoft HTTP Client Libraries" v2.2.28
	6. Add "Microsoft Async" v1.0.168
	7. Add "Microsoft BCL Build Components" v1.0.14